"use strict";!function(){const e=document.querySelector("#invoice-message"),t=e.textContent.replace(/^\s+|\s+$/gm,"");e.value=t}();
